/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.SQLutil.propertyFunctions;

/**
 *
 * @author Ben
 */

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import vacation.SQLutil.utilities.DBUtil;
//import music.ProductOps.*;
import vacation.SQLutil.propertyFunctions.property.*;

public class propertyDB {
    
      public static boolean exists(String property) {
        property p = selectProperty(property);   
        return p != null;
    }

 public static property selectProperty(String property_code) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String qString = "SELECT p FROM property p " +
                "WHERE p.property = :property_code";
        TypedQuery<property> q = em.createQuery(qString, property.class);
        q.setParameter("property_code", property_code);
        try {
            property property = q.getSingleResult();
            return property;
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }      
      
    public static property selectProperties() {  
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String qString = "SELECT * FROM properties.properties";
        TypedQuery<property> q = em.createQuery(qString, property.class);
        String property_code = "*";
        q.setParameter("property_code", property_code);
        try {
            property properties = q.getSingleResult();
            return properties;
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
    
    public static void insertProperty(property property) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
       
        EntityTransaction trans = em.getTransaction();
        trans.begin();        
        try {
            em.persist(property);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
        
    }
    public static void updateProperty(property property) {
         EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();       
        try {
            em.merge(property);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
        
    }
     public static void deleteProperty(property property) {
          EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();        
        try {
            em.remove(em.merge(property));
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }       
     }
     
     
     
    public static void init(String filename) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void insertProperty(vacation.SQLutil.propertyFunctions.property toAdd) {
        insertProperty(toAdd);
       
    }

    static void updateProperty(vacation.SQLutil.propertyFunctions.property toChange) {
        updateProperty(toChange);
        
    }

    private static class property {

        public property() {
        }
    }
    
}
