package vacation.SQLutil.propertyFunctions;



/* redirects to addproductpage  page to add products to productList.txt
 * 
 */
import vacation.SQLutil.propertyFunctions.*;
import vacation.SQLutil.propertyFunctions.property;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import vacation.SQLutil.utilities.*;


public class propertyAdd extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/newProperty.jsp";
        String code = (String)request.getParameter("property_id");
        Boolean DcStar = false;
        
        if(propertyDB.exists(code)){   ///
            url = "/editProperty.jsp";
            DcStar = false;
            request.setAttribute("DcStar", DcStar);
            request.setAttribute("code", code);
 //           request.setAttribute("property_address", propertyDB.selectProperty(code).getAddress());  ///
 //           request.setAttribute("property_phone_number", propertyDB.selectProperty(code).getPhoneNumber());///
            getServletContext().getRequestDispatcher(url).forward(request, response);
        
        
        }else if (!code.equalsIgnoreCase("0000")){
        //} else {
            url = "/editProperty.jsp";
            DcStar = false;
            request.setAttribute("DcStar", DcStar);
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
            
         else if (code.equalsIgnoreCase("0001")){
             DcStar = true;
             request.setAttribute("DcStar", DcStar);
             url = "/newProperty.jsp";
             getServletContext().getRequestDispatcher(url).forward(request, response);
        } 
         else{
           
             getServletContext().getRequestDispatcher(url).forward(request, response);
        
    }
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    }