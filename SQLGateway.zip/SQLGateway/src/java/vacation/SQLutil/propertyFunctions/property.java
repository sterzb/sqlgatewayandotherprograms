/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.SQLutil.propertyFunctions;
import java.text.NumberFormat;
import java.io.Serializable;
import javax.persistence.*;
/**
 *
 * @author Ben
 */
public class property {

    private String property_id = "";///
    private String property_name = "";///
    private String property_address = "";///
    private String property_phone_number = "";///
    private String property_special_notes = "";////
    private String property_main_contact = "";/////
    private String property_mult_owners = "";/////
    private String property_repair_dollar_amount = "";/////
    private String property_contact_before_repair = "";/////
    private String property_key_type = "";/////
    private String property_key_number = "";/////
    private String property_asset_type = "";/////
    private String property_manager = "";/////
    private String property_community_code = "";/////
    private String property_location_type = "";//////
    private String property_turnaround_day = "";/////
    private String property_location = "";//////
    private String property_discount_amount = "";//////
    private String property_discount_date = "";//
    private String property_pet_freindly = "";////
    private String property_pool = "";/////
    private String property_grill = "";/////
    private String property_fireplace = "";/////
    private String property_golf_cart = "";//////
    private String property_type_of_sewage = "";/////
    private String property_type_of_AC = "";//////
    private String property_number_of_floors = "";////
    private String property_on_market = "";/////
    private String property_active = "";//////
    private String property_code_change_frequency = "";//////
    
    
    
    
    

    
    
public property() {
        String property_id = "";
        String property_name = "";
        String property_phone_number="";
        
    }
public property(String property_id) {
       
        this.property_id = property_id;
}

public void setID(String property_id) {
        this.property_id = property_id;
    }

    public String getID() {
        return property_id;
    }

public void setName(String property_name) {
        this.property_name = property_name;
    }

    public String getName() {
        return property_name;        
    }
public void setAddress(String property_address) {
        this.property_address = property_address;
    }

    public String getAddress() {
        return property_address;
    }
public void setPhoneNumber(String property_phone_number) {
        this.property_phone_number = property_phone_number;
    }

    public String getPhoneNumber() {
        return property_phone_number;
    }

public void setSpecialNotes(String property_special_notes) {
        this.property_special_notes = property_special_notes;
    }

    public String getSpecialNotes() {
        return property_special_notes;
    }
public void setMainContact(String property_main_contact) {
        this.property_main_contact = property_main_contact;
    }

    public String getMainContact() {
        return property_main_contact;

}
public void setPropertyMultOwners(String property_mult_owners) {
        this.property_mult_owners = property_mult_owners;
    }

    public String getPropertyMultOwners() {
        return property_mult_owners;
    }
           
public void setRepairDollarAmount(String property_repair_dollar_amount) {
        this.property_repair_dollar_amount = property_repair_dollar_amount;
    }

    public String getRepairDollarAmount() {
        return property_repair_dollar_amount;
}   
    
public void setPropertyContactBeforeRepair(String property_contact_before_repair) {
        this.property_contact_before_repair = property_contact_before_repair;
    }

    public String getPropertyContactBeforeRepair() {
        return property_contact_before_repair;    
    }
public void setPropertyKeyType(String property_key_type) {
        this.property_key_type = property_key_type;
    }

    public String getPropertyKeyType() {
        return property_key_type;
    }  
public void setPropertyKeyNumber(String property_key_number) {
        this.property_key_number = property_key_number;
    }

    public String getPropertyKeyNumber() {
        return property_key_number;
    }
    
public void setPropertyAssetType(String property_asset_type) {
        this.property_asset_type = property_asset_type;
    }

    public String getPropertyAssetType() {
        return property_asset_type;
    }
    
public void setPropertyManager(String property_manager) {
        this.property_manager = property_manager;
    }

    public String getPropertyManager() {
        return property_manager;
    }
    
public void setPropertyCommunityCode(String property_community_code) {
        this.property_community_code = property_community_code;
    }

    public String getPropertyCommunityCode() {
        return property_community_code;
    }
    
public void setPropertyLocationType(String property_location_type) {
        this.property_location_type = property_location_type;
    }

    public String getPropertyLocationType() {
        return property_location_type;
    }        

public void setPropertyTurnaroundDay(String property_turnaround_day) {
        this.property_turnaround_day = property_turnaround_day;
    }

    public String getPropertyTurnaroundDay() {
        return property_turnaround_day;
    }
    
public void setPropertyLocation(String property_location) {
        this.property_location = property_location;
    }

    public String getPropertyLocation() {
        return property_location;
    }
    
public void setPropertyDiscountAmount(String property_discount_amount) {
        this.property_discount_amount = property_discount_amount;
    }

    public String getPropertyDiscountAmount() {
        return property_discount_amount;
    }
    
  public void setPropertyDiscountDate(String property_discount_date) {
        this.property_discount_date = property_discount_date;
    }

    public String getPropertyDiscountDate() {
        return property_discount_date;
    }
    
    
 public void setPropertyPetFreindly(String property_pet_freindly) {
        this.property_pet_freindly = property_pet_freindly;
    }

    public String getPropertyPetFreindly() {
        return property_pet_freindly;   
    }
    
public void setPropertyPool(String property_pool) {
        this.property_pool = property_pool;
    }

    public String getPropertyPool() {
        return property_pool;
    } 

public void setPropertyGrill(String property_grill) {
        this.property_grill = property_grill;
    }

    public String getPropertyGrill() {
        return property_grill;
    }
    
public void setPropertyFireplace(String property_fireplace) {
        this.property_fireplace = property_fireplace;
    }

    public String getPropertyFireplace() {
        return property_fireplace;
    }
    
public void setPropertyGolfCart(String property_golf_cart) {
        this.property_golf_cart = property_golf_cart;
    }

    public String getPropertyGolfCart() {
        return property_golf_cart;
    }
    
public void setPropertyTypeOfSewage(String property_type_of_sewage) {
        this.property_type_of_sewage = property_type_of_sewage;
    }

    public String getPropertyTypeOfSewage() {
        return property_type_of_sewage;
    }
    
public void setPropertyTypeOfAC(String property_type_of_AC) {
        this.property_type_of_AC = property_type_of_AC;
    }

    public String getPropertyTypeOfAC() {
        return property_type_of_AC;
    }
    
public void setPropertyNumberOfFloors(String property_number_of_floors) {
        this.property_number_of_floors = property_number_of_floors;
    }

    public String getPropertyNumberOfFloors() {
        return property_number_of_floors;
    }
    
public void setPropertyOnMarket(String property_on_market) {
        this.property_on_market = property_on_market;
    }

    public String getPropertyOnMarket() {
        return property_on_market;
    }
    
public void setPropertyActive(String property_active) {
        this.property_active = property_active;
    }

    public String getPropertyActive() {
        return property_active;
    }
    
public void setPropertyCodeChangeFrequency(String property_code_change_frequeny) {
        this.property_code_change_frequency = property_code_change_frequency;
    }

    public String getPropertyCodeChangeFrequency() {
        return property_code_change_frequency;
    }
    
}
