package vacation.SQLutil.propertyFunctions;

/*
 * this servlet is called when changing a property
 */
import vacation.SQLutil.utilities.*;
import vacation.SQLutil.propertyFunctions.property;
import vacation.SQLutil.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import vacation.SQLutil.propertyFunctions.propertyDB;

/**
 *
 * @author juggalo6
 */
public class propertyChange extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet: PChange</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet /PChange at " + request.getContextPath() + "</h1>");
            out.println("If you are here, you shold not be and the ninja mice will be there shortly to fix that");
            out.println("I would suggest giving them cheese, but lately they call that profiling");
            out.println("It was nice knowing you, kinda..");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
       
        if(action.equalsIgnoreCase("add")){
            String property_id = request.getParameter("property_id"); 
            String property_name = request.getParameter("property_name");
            String property_address = request.getParameter("property_address");
            String property_phone_number = request.getParameter("property_phone_number");
            String property_special_notes = request.getParameter("property_special_notes");
            String property_main_contact = request.getParameter("property_main_contact");
            String property_mult_owners = request.getParameter("property_mult_owners");
            String property_repair_dollar_amount = request.getParameter("property_repair_dollar_amount");
            String property_contact_before_repair = request.getParameter("property_contact_amount_before_repair");
            String property_key_type = request.getParameter("property_key_type");
            String property_key_number = request.getParameter("property_key_number");
            String property_asset_type = request.getParameter("property_asset_type");
            String property_manager = request.getParameter("property_manager");
            String property_community_code = request.getParameter("property_community_code");
            String property_location_type = request.getParameter("property_location_type");
            String property_turnaround_day = request.getParameter("property_turnaround_day");
            String property_location = request.getParameter("property_location");
            String property_discount_amount = request.getParameter("property_discount_amount");
            String property_discount_date = request.getParameter("property_discount_date");
            String property_pet_freindly = request.getParameter("property_pet_freindly");
            String property_pool = request.getParameter("property_pool");
            String property_grill = request.getParameter("property_grill");
            String property_fireplace = request.getParameter("property_fireplace");
            String property_golf_cart = request.getParameter("property_golf_cart");
            String property_type_of_sewage = request.getParameter("property_type_of_sewage");
            String property_type_of_AC = request.getParameter("property_type_of_AC");
            String property_number_of_floors = request.getParameter("property_number_of_floors");
            String property_on_market = request.getParameter("property_on_market");
            String property_active = request.getParameter("property_active");
            String property_code_change_frequency = request.getParameter("property_code_change_frequency");
            
            property toAdd = new property();
            toAdd.setID(property_id);
            toAdd.setName(property_name);
            toAdd.setAddress(property_address);
            toAdd.setPhoneNumber(property_phone_number);
            toAdd.setSpecialNotes(property_special_notes);
            toAdd.setMainContact(property_main_contact);
            toAdd.setPropertyMultOwners(property_mult_owners);
            toAdd.setRepairDollarAmount(property_repair_dollar_amount);
            toAdd.setPropertyContactBeforeRepair(property_contact_before_repair);
            toAdd.setPropertyKeyType(property_key_type);       
            toAdd.setPropertyKeyNumber(property_key_number);
            toAdd.setPropertyAssetType(property_asset_type);        
            toAdd.setPropertyManager(property_manager);
            toAdd.setPropertyCommunityCode(property_community_code);
            toAdd.setPropertyLocationType(property_location_type);
            toAdd.setPropertyTurnaroundDay(property_turnaround_day);
            toAdd.setPropertyLocation(property_location);
            toAdd.setPropertyDiscountAmount(property_discount_amount);
            toAdd.setPropertyDiscountDate(property_discount_date);
            toAdd.setPropertyPetFreindly(property_pet_freindly);
            toAdd.setPropertyPool(property_pool);        
            toAdd.setPropertyGrill(property_grill);
            toAdd.setPropertyFireplace(property_fireplace);
            toAdd.setPropertyGolfCart(property_golf_cart);        
            toAdd.setPropertyTypeOfSewage(property_type_of_sewage);
            toAdd.setPropertyTypeOfAC(property_type_of_AC);
            toAdd.setPropertyNumberOfFloors(property_number_of_floors);        
            toAdd.setPropertyOnMarket(property_on_market);
            toAdd.setPropertyActive(property_active);
            toAdd.setPropertyCodeChangeFrequency(property_code_change_frequency);            

            propertyDB.insertProperty(toAdd);
            
            
            
            
            
            
            
            HttpSession session = request.getSession();
            session.setAttribute("property_id", property_id);
            session.setAttribute("property_name", property_name);
            session.setAttribute("property_address", property_address);
            session.setAttribute("property_phone_number", property_phone_number);
            session.setAttribute("property_special_notes", property_special_notes);
            session.setAttribute("property_main_contact", property_main_contact);
            session.setAttribute("property_mult_owners", property_mult_owners);
            session.setAttribute("property_repair_dollar_amount", property_repair_dollar_amount);
            session.setAttribute("property_contact_before_repair", property_contact_before_repair);
            session.setAttribute("property_key_type", property_key_type);
            session.setAttribute("property_key_number", property_key_number);
            session.setAttribute("property_asset_type", property_asset_type);
            session.setAttribute("property_manager", property_manager);
            session.setAttribute("property_community_code", property_community_code);
            session.setAttribute("property_location_type", property_location_type);
            session.setAttribute("property_turnaround_day", property_turnaround_day);
            session.setAttribute("property_location", property_location);
            session.setAttribute("property_discount_amount", property_discount_amount);
            session.setAttribute("property_discount_date", property_discount_date);
            session.setAttribute("property_pet_freindly", property_pet_freindly);
            session.setAttribute("property_pool", property_pool);
            session.setAttribute("property_grill", property_grill);
            session.setAttribute("property_fireplace", property_fireplace);
            session.setAttribute("property_golf_cart", property_golf_cart);
            session.setAttribute("property_type_of_sewage", property_type_of_sewage);
            session.setAttribute("property_type_of_AC", property_type_of_AC);
            session.setAttribute("property_number_of_floors", property_number_of_floors);
            session.setAttribute("property_on_market", property_on_market);
            session.setAttribute("property_active", property_active);
            session.setAttribute("property_code_change_frequency", property_code_change_frequency);
            
            if ( property_id.isEmpty() || property_name.isEmpty()|| property_phone_number.isEmpty() ) // Add missing QA check
            {
                // forward to the view to get missing parameters
                String url = "editProperty.jsp";
            
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
            
            
         } else{
              response.sendRedirect("/SQLGateway/propertyAdd");  
            } 
        }
        else if(action.equalsIgnoreCase("update")){
            String property_id = request.getParameter("property_id");
            String property_name = request.getParameter("property_name");
            String property_phone_number = request.getParameter("property_phone_number");
            String property_special_notes = request.getParameter("property_special_notes");
            String property_main_contact = request.getParameter("property_main_contact");
            String property_mult_owners = request.getParameter("property_mult_owners");
            String property_repair_dollar_amount = request.getParameter("property_repair_dollar_amount");
            String property_contact_before_repair = request.getParameter("property_contact_amount_before_repair");
            String property_key_type = request.getParameter("property_key_type");
            String property_key_number = request.getParameter("property_key_number");
            String property_asset_type = request.getParameter("property_asset_type");
            String property_manager = request.getParameter("property_manager");
            String property_community_code = request.getParameter("property_community_code");
            String property_location_type = request.getParameter("property_location_type");
            String property_turnaround_day = request.getParameter("property_turnaround_day");
            String property_location = request.getParameter("property_location");
            String property_discount_amount = request.getParameter("property_discount_amount");
            String property_discount_date = request.getParameter("property_discount_date");
            String property_pet_freindly = request.getParameter("property_pet_freindly");
            String property_pool = request.getParameter("property_pool");
            String property_grill = request.getParameter("property_grill");
            String property_fireplace = request.getParameter("property_fireplace");
            String property_golf_cart = request.getParameter("property_golf_cart");
            String property_type_of_sewage = request.getParameter("property_type_of_sewage");
            String property_type_of_AC = request.getParameter("property_type_of_AC");
            String property_number_of_floors = request.getParameter("property_number_of_floors");
            String property_on_market = request.getParameter("property_on_market");
            String property_active = request.getParameter("property_active");
            String property_code_change_frequency = request.getParameter("property_code_change_frequency");
            
            property toChange = new property();
            toChange.setID(property_id);
            toChange.setName(property_name);
            toChange.setPhoneNumber(property_phone_number);
            toChange.setSpecialNotes(property_special_notes);
            toChange.setMainContact(property_main_contact);
            toChange.setPropertyMultOwners(property_mult_owners);
            toChange.setRepairDollarAmount(property_repair_dollar_amount);
            toChange.setPropertyContactBeforeRepair(property_contact_before_repair);
            toChange.setPropertyKeyType(property_key_type);       
            toChange.setPropertyKeyNumber(property_key_number);
            toChange.setPropertyAssetType(property_asset_type);        
            toChange.setPropertyManager(property_manager);
            toChange.setPropertyCommunityCode(property_community_code);
            toChange.setPropertyLocationType(property_location_type);
            toChange.setPropertyTurnaroundDay(property_turnaround_day);
            toChange.setPropertyLocation(property_location);
            toChange.setPropertyDiscountAmount(property_discount_amount);
            toChange.setPropertyDiscountDate(property_discount_date);
            toChange.setPropertyPetFreindly(property_pet_freindly);
            toChange.setPropertyPool(property_pool);        
            toChange.setPropertyGrill(property_grill);
            toChange.setPropertyFireplace(property_fireplace);
            toChange.setPropertyGolfCart(property_golf_cart);        
            toChange.setPropertyTypeOfSewage(property_type_of_sewage);
            toChange.setPropertyTypeOfAC(property_type_of_AC);
            toChange.setPropertyNumberOfFloors(property_number_of_floors);        
            toChange.setPropertyOnMarket(property_on_market);
            toChange.setPropertyActive(property_active);
            toChange.setPropertyCodeChangeFrequency(property_code_change_frequency);            
            propertyDB.updateProperty(toChange);
            response.sendRedirect("/SQLGateway/newProperty.jsp");
             
            HttpSession session = request.getSession();
            session.setAttribute("property_id", property_id);
            session.setAttribute("property_name", property_name);
            session.setAttribute("property_phone_number", property_phone_number);
            session.setAttribute("property_special_notes", property_special_notes);
            session.setAttribute("property_main_contact", property_main_contact);
            session.setAttribute("property_mult_owners", property_mult_owners);
            session.setAttribute("property_repair_dollar_amount", property_repair_dollar_amount);
            session.setAttribute("property_contact_before_repair", property_contact_before_repair);
            session.setAttribute("property_key_type", property_key_type);
            session.setAttribute("property_key_number", property_key_number);
            session.setAttribute("property_asset_type", property_asset_type);
            session.setAttribute("property_manager", property_manager);
            session.setAttribute("property_community_code", property_community_code);
            session.setAttribute("property_location_type", property_location_type);
            session.setAttribute("property_turnaround_day", property_turnaround_day);
            session.setAttribute("property_location", property_location);
            session.setAttribute("property_discount_amount", property_discount_amount);
            session.setAttribute("property_discount_date", property_discount_date);
            session.setAttribute("property_pet_freindly", property_pet_freindly);
            session.setAttribute("property_pool", property_pool);
            session.setAttribute("property_grill", property_grill);
            session.setAttribute("property_fireplace", property_fireplace);
            session.setAttribute("property_golf_cart", property_golf_cart);
            session.setAttribute("property_type_of_sewage", property_type_of_sewage);
            session.setAttribute("property_type_of_AC", property_type_of_AC);
            session.setAttribute("property_number_of_floors", property_number_of_floors);
            session.setAttribute("property_on_market", property_on_market);
            session.setAttribute("property_active", property_active);
            session.setAttribute("property_code_change_frequency", property_code_change_frequency);

            if ( property_id.isEmpty() || property_name.isEmpty() || property_phone_number.isEmpty())//////add missing QA check
            {
                // forward to the view to get missing parameters
                String url = "editProperty.jsp";
            
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
      
        } else{
             response.sendRedirect("/SQLGateway/newProperty.jsp");
        }
    }
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    
//    private String checkUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
//        String url = "/Application1222/VProductMaint";
//        String code = request.getParameter("code");
//        String desc = request.getParameter("description");
//        Double cost = Double.parseDouble(request.getParameter("price"));
        
//        if (code == null || desc == null || cost == null){
//            Boolean DcStar = true;
//            request.setAttribute("DcStar", DcStar);
//            response.sendRedirect("/Application1222/VProductMaint");
//            try {
//                getServletContext().getRequestDispatcher(url).forward(request, response);
//            } catch (ServletException ex) {
//                Logger.getLogger(PChange.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(PChange.class.getName()).log(Level.SEVERE, null, ex);
//            }
            
           
 //       } 
  //  return url;
//    }
    
}
              