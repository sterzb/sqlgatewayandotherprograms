package vacation.SQLutil.utilities;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import music.ProductOps.Product;


public class SQLUtil {

    public static String getHtmlTable(ResultSet results)
            throws SQLException {
        
        StringBuilder htmlTable = new StringBuilder();
        ResultSetMetaData metaData = results.getMetaData();
        int columnCount = metaData.getColumnCount();

        htmlTable.append("<table border = 1 >");

        // add header row
        htmlTable.append("<tr>");
        for (int i = 1; i <= columnCount; i++) {
            htmlTable.append("<th>");
            htmlTable.append(metaData.getColumnName(i));
            htmlTable.append("</th>");
        
        }
        htmlTable.append("<td>");
        htmlTable.append("<b>Edit</b>");
                     
        htmlTable.append("</td>");
        htmlTable.append("<td>");
        htmlTable.append("<b>Delete</b>");
        htmlTable.append("</td>");
        
        htmlTable.append("</tr>");

        // add all other rows
        while (results.next()) {
            htmlTable.append("<tr>");
            for (int i = 1; i <= columnCount; i++) {
                htmlTable.append("<td>");
                htmlTable.append(results.getString(i));
                htmlTable.append("</td>");
                htmlTable.append("<td>");
                htmlTable.append("Edit");
                htmlTable.append("</td>");
                htmlTable.append("<td>)");
                htmlTable.append("Delete");
                htmlTable.append("</td>");
            }
            
            htmlTable.append("<td>");
            htmlTable.append("<a href=/SQLGateway/propertyAdd>Edit Property</a>");
            htmlTable.append("<a href=/SQLGateway/ownerAdd >Edit Owner</a>");
            htmlTable.append("</td>");
            htmlTable.append("<td>");
            htmlTable.append("<a href=/SQLGateway/confirmDeleteProperty.jsp>Delete Property</a>");
            htmlTable.append("<a href=/SQLGateway/confirmDeleteOwner.jsp>Delete Owner</a>");
            htmlTable.append("</td>");
    //        <td>   <a href=<c:url value = "VAdd" var = "Addcode">
    //                   <c:param name= "code" value ="${Product.getCode()}"/> </c:url>${Addcode} > Edit </a> </td>
    //        <td><a href = <c:url value="VConfirmDelete"><c:param name="action" value = "delete"></c:param>
    //                <c:param name="code" value="${Product.getCode()}">
    //                </c:param> </c:url>> Delete </a></td>
            
            
            htmlTable.append("</tr>");
        }

        htmlTable.append("</table>");
        return htmlTable.toString();
    }
}