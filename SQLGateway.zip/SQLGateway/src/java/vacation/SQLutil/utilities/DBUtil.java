/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.SQLutil.utilities;
//
//persistance class
//
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {
    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("propertylistPU");
    public static EntityManagerFactory getEmFactory() {    //for properties
        return emf;
    }
            
    private static final EntityManagerFactory amf =
            Persistence.createEntityManagerFactory("ownerlistPU");
    
    public static EntityManagerFactory getAmFactory() {   //for owners
        return amf;   
}
}
