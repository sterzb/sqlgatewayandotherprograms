package vacation.SQLutil.ownerFunctions;

/*
 * this servlet is called when changing a property
 */
import vacation.SQLutil.ownerFunctions.*;
import vacation.SQLutil.utilities.*;
import vacation.SQLutil.ownerFunctions.owner;
import vacation.SQLutil.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import vacation.SQLutil.ownerFunctions.ownerDB;

/**
 *
 * @author juggalo6
 */
public class ownerChange extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet: PChange</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet /PChange at " + request.getContextPath() + "</h1>");
            out.println("If you are here, you shold not be and the ninja mice will be there shortly to fix that");
            out.println("I would suggest giving them cheese, but lately they call that profiling");
            out.println("It was nice knowing you, kinda..");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
       
        
        if(action.equalsIgnoreCase("add")){
            String owner_phone_number = request.getParameter("owner_phone_number"); 
            String owner_name_last = request.getParameter("owner_name_last");
            String owner_name_first = request.getParameter("owner_name_first");
            String owner_name_other = request.getParameter("owner_name_other");
            String owner_address = request.getParameter("owner_address");
            String owner_email = request.getParameter("owner_email");
            String owner_alternate_contact = request.getParameter("owner_alternate_contact");
            String owner_extra_info = request.getParameter("owner_extra_info");
            String extra_information = request.getParameter("extra_information");       
            
            owner toAdd = new owner();
            toAdd.setOwnerPhoneNumber(owner_phone_number);
            toAdd.setOwnerFirstName(owner_name_first);
            toAdd.setOwnerLastName(owner_name_last);
            toAdd.setOwnerOtherName(owner_name_other);
            toAdd.setOwnerAddress(owner_address);
            toAdd.setOwnerEmail(owner_email);
            toAdd.setOwnerAlternateContact(owner_alternate_contact);
            toAdd.setOwnerExtraInfo(owner_extra_info);
            toAdd.setExtraInformation(extra_information);
            ownerDB.insertOwner(toAdd);
            
            
            
            
            
            
            
            HttpSession session = request.getSession();
            session.setAttribute("owner_phone_number", owner_phone_number);
            session.setAttribute("owner_name_first", owner_name_first);
            session.setAttribute("owner_name_last", owner_name_last);
            session.setAttribute("owner_name_other", owner_name_other);
            session.setAttribute("owner_address", owner_address);
            session.setAttribute("owner_email", owner_email);
            session.setAttribute("owner_alternate_contact", owner_alternate_contact);
            session.setAttribute("owner_extra_info", owner_extra_info);
            session.setAttribute("extra_information", extra_information);
            
            if ( owner_phone_number.isEmpty() || owner_name_first.isEmpty()|| owner_name_last.isEmpty() || owner_email.isEmpty() ) // Add missing QA check
            {
                // forward to the view to get missing vital parameters
                String url = "/editOwner.jsp";
            
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
            
            
         } else{
              response.sendRedirect("/SQLGateway/ownerAdd");  
            } 
        }
        else if(action.equalsIgnoreCase("update")){
            String owner_phone_number = request.getParameter("owner_phone_number");
            String owner_name_first = request.getParameter("owner_name_first");
            String owner_name_last = request.getParameter("owner_name_last");
            String owner_name_other = request.getParameter("owner_name_other");
            String owner_address = request.getParameter("owner_address");
            String owner_email = request.getParameter("owner_email");
            String owner_alternate_contact = request.getParameter("owner_alternate_contact");
            String owner_extra_info = request.getParameter("owner_extra_info");
            String extra_information = request.getParameter("extra_information"); 
 
            owner toChange = new owner();
            toChange.setOwnerPhoneNumber(owner_phone_number);
            toChange.setOwnerFirstName(owner_name_first);
            toChange.setOwnerLastName(owner_name_last);
            toChange.setOwnerOtherName(owner_name_other);
            toChange.setOwnerAddress(owner_address);
            toChange.setOwnerEmail(owner_email);
            toChange.setOwnerAlternateContact(owner_alternate_contact);
            toChange.setOwnerExtraInfo(owner_extra_info);
            toChange.setExtraInformation(extra_information);
            ownerDB.updateOwner(toChange);
            response.sendRedirect("/SQLGateway/newOwner.jsp");
             
            HttpSession session = request.getSession();
            session.setAttribute("owner_phone_number", owner_phone_number);
            session.setAttribute("owner_name_first", owner_name_first);
            session.setAttribute("owner_name_last", owner_name_last);
            session.setAttribute("owner_name_other", owner_name_other);
            session.setAttribute("owner_address", owner_address);
            session.setAttribute("owner_email", owner_email);
            session.setAttribute("owner_alternate_contact", owner_alternate_contact);
            session.setAttribute("owner_extra_info", owner_extra_info);
            session.setAttribute("extra_information", extra_information);
            
            if ( owner_phone_number.isEmpty() || owner_name_first.isEmpty() || owner_name_last.isEmpty() || owner_email.isEmpty() )//////add missing QA check
            {
                // forward to the view to get missing vital parameters
                String url = "/editOwner.jsp";
            
            getServletContext().getRequestDispatcher(url)
                .forward(request, response);
      
        } else{
             response.sendRedirect("/SQLGateway/newOwner.jsp");
             //add confirmNewOwner.jsp
             
        }
    }
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    
//    private String checkUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
//        String url = "/Application1222/VProductMaint";
//        String code = request.getParameter("code");
//        String desc = request.getParameter("description");
//        Double cost = Double.parseDouble(request.getParameter("price"));
        
//        if (code == null || desc == null || cost == null){
//            Boolean DcStar = true;
//            request.setAttribute("DcStar", DcStar);
//            response.sendRedirect("/Application1222/VProductMaint");
//            try {
//                getServletContext().getRequestDispatcher(url).forward(request, response);
//            } catch (ServletException ex) {
//                Logger.getLogger(PChange.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(PChange.class.getName()).log(Level.SEVERE, null, ex);
//            }
            
           
 //       } 
  //  return url;
//    }
    
}
              