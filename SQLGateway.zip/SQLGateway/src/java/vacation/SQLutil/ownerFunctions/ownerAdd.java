package vacation.SQLutil.ownerFunctions;



/* redirects to addproductpage  page to add products to productList.txt
 * 
 */
import vacation.SQLutil.propertyFunctions.propertyDB;
import vacation.SQLutil.ownerFunctions.owner.*;
import vacation.SQLutil.ownerFunctions.ownerDB;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ownerAdd extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/newOwner.jsp";
        String code = (String)request.getParameter("code");
        Boolean DcStar = false;
        
        if(ownerDB.exists(code)){   ///
            url = "/editOwner.jsp";
            DcStar = false;
            request.setAttribute("DcStar", DcStar);
            request.setAttribute("code", code);
//           /// request.setAttribute("description", propertyDB.selectProperty(code).getAddress());  ///
            ///request.setAttribute("price", PropertyDB.selectProperty(code).getPrice());///
            getServletContext().getRequestDispatcher(url).forward(request, response);
        
        
        }else if (!code.equalsIgnoreCase("0000")){
        //} else {
            url = "/editOwner.jsp";
            DcStar = false;
            request.setAttribute("DcStar", DcStar);
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
            
         else if (code.equalsIgnoreCase("0001")){
             DcStar = true;
             request.setAttribute("DcStar", DcStar);
             url = "/newOwner.jsp";
             getServletContext().getRequestDispatcher(url).forward(request, response);
        } 
         else{
           
             getServletContext().getRequestDispatcher(url).forward(request, response);
        
    }
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    }