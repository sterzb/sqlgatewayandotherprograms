package vacation.SQLutil.ownerFunctions;



import vacation.SQLutil.ownerFunctions.ownerDB;
import vacation.SQLutil.ownerFunctions.ownerDB.*;
import vacation.SQLutil.ownerFunctions.owner.*;
import vacation.SQLutil.ownerFunctions.deleteOwner.*;
import vacation.*;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class deleteOwner extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Delete</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Delete at " + request.getContextPath() + "</h1>");
            out.println("Hi there, I see you found the wrong page.  Well that's not good.");
            out.println("Needs more cowbell.  - Christopher Walken");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String code = request.getParameter("owner_phone_number");
        String conf = request.getParameter("Conf");
        if (conf.equalsIgnoreCase("yes")) {
            ownerDB.deleteOwner(ownerDB.selectOwner(code));
            response.sendRedirect("/SQLGateway/SqlGatewayServlet");
        }
        else 
            response.sendRedirect("/SQLGateway/SqlGatewayServlet");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request,response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}

