package vacation.SQLutil.ownerFunctions;
import java.text.NumberFormat;
import java.io.Serializable;
import javax.persistence.*;
import vacation.SQLutil.ownerFunctions.ownerDB.*;
/**
 *
 * @author Ben
 */
public class owner {

   private String owner_name_last = "";
   private String owner_name_first = "";
   private String owner_name_other = "";
   private String owner_phone_number = "";
   private String owner_address = "";
   private String owner_email = "";
   private String owner_alternate_contact = "";
   private String owner_extra_info = "";
   private String extra_information = "";
   
   
    ////etc,etc,etc///////
    
    
    

    
    
public owner() {
        String owner_phone_number ="";
        String owner_name_last = "";
        String owner_name_first = "";
       
        
    }
public owner(String owner_name_last) {
       
        this.owner_name_last = owner_name_last;
}
//////////////////owner getters and setters//////////////////////////////
public void setOwnerLastName(String owner_name_last) {
        this.owner_name_last = owner_name_last;
    }

    public String getOwnerLastName() {
        return owner_name_last;
    }
public void setOwnerFirstName(String owner_name_first) {
        this.owner_name_first = owner_name_first;
    }

    public String getOwnerFirstName() {
        return owner_name_first;
    }    

    //////////////others////////////////////////
public void setOwnerOtherName(String owner_name_other) {
        this.owner_name_other = owner_name_other;
    }

    public String getOwnerOtherName() {
        return owner_name_other;
    }
    
public void setOwnerPhoneNumber(String owner_phone_number) {
        this.owner_phone_number = owner_phone_number;
    }

    public String getOwnerPhoneNumber() {
        return owner_phone_number;
    }
    
public void setOwnerAddress(String owner_address) {
        this.owner_address = owner_address;
    }

    public String getOwnerAddress() {
        return owner_address;
    }
    
public void setOwnerEmail(String owner_emaill) {
        this.owner_email = owner_email;
    }

    public String getOwnerEmail() {
        return owner_email;
    }
    

public void setOwnerAlternateContact(String owner_alternate_contact) {
        this.owner_alternate_contact = owner_alternate_contact;
    }

    public String getOwnerAlternateContact() {
        return owner_alternate_contact;
    }
    
public void setOwnerExtraInfo(String owner_extra_info) {
        this.owner_extra_info = owner_extra_info;
    }

    public String getOwnerExtraInfo() {
        return owner_extra_info;
    }
    
public void setExtraInformation(String extra_information) {
        this.extra_information = extra_information;
    }

    public String getExtraInformation() {
        return extra_information;
    }
    
    }
    
