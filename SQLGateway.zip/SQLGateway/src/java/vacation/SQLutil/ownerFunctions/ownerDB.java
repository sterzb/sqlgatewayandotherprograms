/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.SQLutil.ownerFunctions;

/**
 *
 * @author Ben
 */

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import vacation.SQLutil.utilities.DBUtil;
import static vacation.SQLutil.ownerFunctions.owner.*;

public class ownerDB {
    
      public static boolean exists(String owner) {
        owner o = selectOwner(owner);  
           return o != null;
     
      }

public static owner selectOwner(String owner_code) {
        EntityManager am = DBUtil.getEmFactory().createEntityManager();
        String qString = "SELECT o FROM owner o " +
                "WHERE o.owner = :owner_code";
        TypedQuery<owner> q = am.createQuery(qString, owner.class);
        q.setParameter("owner_code", owner_code);
        try {
            owner owner = q.getSingleResult();
            return owner;
        } catch (NoResultException e) {
            return null;
        } finally {
            am.close();
        }
    }      
      
    public static owner selectOwners() {  
        EntityManager am = DBUtil.getEmFactory().createEntityManager();
        String qString = "SELECT * FROM properties.owners";
        TypedQuery<owner> q = am.createQuery(qString, owner.class);
        String owner_code = "*";
        //q.setParameter("productcode", productcode);
        try {
            owner owners = q.getSingleResult();
            return owners;
        } catch (NoResultException e) {
            return null;
        } finally {
            am.close();
        }
    }
    
    public static void insertOwner(owner owner) {
        EntityManager am = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = am.getTransaction();
        trans.begin();        
        try {
            am.persist(owner);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            am.close();
        }
        
    }
    public static void updateOwner(owner owner) {
         EntityManager am = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = am.getTransaction();
        trans.begin();       
        try {
            am.merge(owner);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            am.close();
        }
        
    }
     public static void deleteOwner(owner owner) {
          EntityManager am = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = am.getTransaction();
        trans.begin();        
        try {
            am.remove(am.merge(owner));
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            am.close();
        }       
     }
     
   
    public static void init(String filename) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
